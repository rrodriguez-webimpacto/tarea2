<?php

// Load PRESTASHOP

include_once(dirname(__FILE__).'/config/config.inc.php');
include_once(dirname(__FILE__).'/init.php');


class Tarea2
{

    public function addProducts()
    {
        
        global $fila;
        global $tax_name;

        $fila = 1;

        // Recorrer CSV
        if (($gestor = fopen("products.csv", "r")) !== FALSE) {
            
            while (($datos = fgetcsv($gestor, 1000, ",")) !== FALSE) {

                echo '<h3> FILA Nº: ' . $fila . '</h3>';

                if($fila == 1){
                    $tax_name = $datos[5];
                }

                if($fila > 1){

                    // CATEGORÍAS ✔️
                    $id_categoria;

                    
                    // Prueba si existe la categoría en el CSV
                    if(isset($datos[7])){
                        
                        $categorias = explode(";", $datos[7]);

                        $id_parent = 0;
                        
                        foreach($categorias as $cat){

                            
                            // Prueba si existe la categoría en la BD
                            $exist_cat = Category::searchByName(1,$cat);

                            if(empty($exist_cat)){

                                $categoria = new Category();

                                $categoria->id_parent = $id_parent;                      
                                $categoria->active = 1;          
                                
                                $categoria->name = array();
                                $categoria->link_rewrite = array();

                                // Formateamos el string cat
                                $formated_cat = Tarea2::format_link_rewrite($cat);

                                foreach (Language::getLanguages(false) as $lang){
                                    $categoria->name[$lang['id_lang']] = $cat;
                                    $categoria->link_rewrite[$lang['id_lang']] = $formated_cat;
                                }

                                $save_bd = $categoria->add();
                                if($save_bd){
                                    echo 'Categoria <strong> ' . $cat . ' </strong> guardada correctamente en la BD <br>';
                                }else{
                                    echo 'No se ha podido guardar la categoria correctamente en la base de datos';
                                } 

                                $id_parent = Db::getInstance()->Insert_ID();
                                $id_categoria = $id_parent;
                            }else{
                                // Asignar id_parent
                                $id_parent = $exist_cat[0]['id_category'];
                                $id_categoria = $id_parent;
                                echo 'La categoría <strong> ' . $cat . ' </strong> ya existe en la BD <br>';
                            }
                            
                        }
                    }


                     // MARCA ✔️
                     $id_marca;

                     // Prueba si existe la marca en el csv
                    if(isset($datos[8])){

                        // Prueba si existe la marca en la BD
                        $exist_man = Manufacturer::getIdByName($datos[8]);

                        if($exist_man == false){
                            $manufacturer = new Manufacturer();
                            $manufacturer->name = $datos[8];
                            $manufacturer->active = 1;
                            $save_bd = $manufacturer->add();

                            if($save_bd){
                                echo 'Marca <strong> ' . $manufacturer->name . ' </strong>guardada correctamente en la BD <br>';
                            }else{
                                echo 'No se ha podido guardar la marca en la base de datos';
                            }
                            $id_marca = Db::getInstance()->Insert_ID(); 
                        }else{
                            echo 'La marca <strong> ' . $manufacturer->name . ' </strong>ya existe en la BD <br>';
                            $id_marca = $exist_man;
                        }
                    }


                    // TASAS ✔️ 

                    $id_tasas;
                    // Prueba si existe el tax en el CSV
                    if(isset($datos[5])){

                        // Prueba si existe el tax en la BD
                        $tax_full_name = $tax_name . ' ES ' . $datos[5] . '%';
                        $id_tax = Tax::getTaxIdByName($tax_full_name);

                        
                        if($id_tax == false){

                            $tax = new TaxCore();

                            $tax->name = array();
                            foreach (Language::getLanguages(false) as $lang){
                                $tax->name[$lang['id_lang']] = $tax_full_name;   
                            }
                            $tax->rate = (float)$datos[5];
                            $tax->active = 1;

                            $save_bd = $tax->add();
                            if($save_bd){
                                echo 'TASA: <strong>' . $tax->name[1] . ' </strong> guardada correctamente en la BD <br>';
                            }else{
                                echo 'No se ha podido guardar la tasa en la base de datos';
                            }
                            $id_tasas = Db::getInstance()->Insert_ID();
                        }else{
                            $id_tasas = $id_tax;
                            echo 'La tasa <strong> ' . $tax_full_name . ' </strong> ya existe en la BD<br>';
                        }
                    }
                    

                    // Comprobación si vienen todos los datos del producto en el CSV
                    $exists_csv = true;
                    for($i = 0; $i < 9 && $exists_csv == true; $i++){
                        if(!isset($datos[$i])){
                            $exists_csv = false;
                        }
                    }
                    if($exists_csv){
                        
                        // Comprobación si el producto existe en la BD
                        $exists_bd = Product::searchByName(1,$datos[0]);

                        if(!$exists_bd){
                            // Crear nuevo producto
                            $producto = new Product();

                            // Añadir propiedades Producto
                            $producto->name = array();
                            foreach (Language::getLanguages(false) as $lang){
                                $producto->name[$lang['id_lang']] = $datos[0];   
                            }
                            $producto->reference = $datos[1];
                            $producto->ean13 = $datos[2];
                            $producto->price = $datos[3];
                            $producto->active = 1;
                            $producto->wholesale_price = $datos[4];
                            $producto->id_shop_default = 1;


                            // Añadir propiedades productos (2)
                            // Categoría
                            if($id_categoria == null){
                                $exist_cat = Category::searchByName(1,$cat);
                                $id_categoria = $exist_cat[0]['id_category'];
                            }
                            $producto->id_category_default = $id_categoria;
                            
                            // Marca
                            if($id_marca == null){
                                $id_marca = $exist_man;
                            }
                            $producto->id_manufacturer = $id_marca;

                            // Tasa
                            if($id_tasa == null){
                                $id_tasa = $id_tax;
                            }
                            $producto->id_tax_rules_group = $id_tasas;

                            // Comprobación guardado en BD
                            $save_bd = $producto->add();
                            if($save_bd){
                                echo 'Producto: ' . $producto->name[1] . ' guardado correctamente en la BD <br>';
                            }else{
                                echo 'No se ha podido guardar el producto en la base de datos';
                            }

                            // Actualizar cantidad producto
                            $last_add_product_id = Db::getInstance()->Insert_ID();
                            $quantity = StockAvailable::getQuantityAvailableByProduct($last_add_product_id);
                            $total_quantity = $quantity + $datos[6];
                            StockAvailable::setQuantity((int)$last_add_product_id, 0, $total_quantity);
                        }
                    }
                    else{
                        echo 'En la línea nº ' . $fila . ' faltan campos en el fichero CSV';
                    }                
                }
                $fila++;

                echo '<br><br>';
            }   
        }
        fclose($gestor);
    }

    public static function format_link_rewrite($cat){
        if(!ctype_space($cat)){
            $formated_cat = str_replace(" ","-",$cat);
        }
        $formated_cat = mb_strtolower($formated_cat);
    
        $formated_cat = str_replace(
            array('á', 'à', 'ä', 'â', 'ª'),
            array('a', 'a', 'a', 'a', 'a'),
            $formated_cat
        );
    
        $formated_cat = str_replace(
            array('é', 'è', 'ë', 'ê'),
            array('e', 'e', 'e', 'e'),
            $formated_cat );
    
        $formated_cat = str_replace(
            array('í', 'ì', 'ï', 'î'),
            array('i', 'i', 'i', 'i'),
            $formated_cat );
    
        $formated_cat = str_replace(
            array('ó', 'ò', 'ö', 'ô'),
            array('o', 'o', 'o', 'o'),
            $formated_cat );
    
        $formated_cat = str_replace(
            array('ú', 'ù', 'ü', 'û'),
            array('u', 'u', 'u', 'u'),
            $formated_cat );
    
        $formated_cat = str_replace(
            array('ñ', 'ç'),
            array('n', 'c'),
            $formated_cat
        );

        return $formated_cat;
    }
}

$tarea2 = new Tarea2();
$tarea2->addProducts();